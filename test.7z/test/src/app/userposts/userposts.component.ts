import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { IUser } from '../user/user';
import { USerService } from '../user/user.service';

@Component({
  selector: 'app-userposts',
  templateUrl: './userposts.component.html',
  styleUrls: ['./userposts.component.css']
})
export class UserpostsComponent implements OnInit {

  constructor(private uSerService: USerService,private _route: ActivatedRoute) { }

  private sub: Subscription = new Subscription;

  id: string = "";
  

  user: IUser[] = [];

  ngOnInit(): void {

    this.sub = this._route.params.subscribe(
      params => {
        let id = params['id'];

        this.id = id;

        console.log(this.id);

      });


    this.uSerService.getUsers().subscribe(
      (data) => {
        this.user = data;
        console.log("user data"+ this.user);
      }
    )

  }

}
