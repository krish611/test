import { HttpClient, HttpClientModule, HttpHandler } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { USerService } from './user/user.service';
import { UserpostsComponent } from './userposts/userposts.component';
import { userRoutes } from './users.routes';

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    UserpostsComponent
  ],
  imports: [
    BrowserModule,HttpClientModule,
    AppRoutingModule,
    RouterModule.forRoot(userRoutes)

  ],
  providers: [USerService  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
