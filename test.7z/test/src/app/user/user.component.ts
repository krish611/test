import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { IUser } from './user';
import { USerService } from './user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private uSerService: USerService,private _route: ActivatedRoute) { }


  
  user: IUser[] = [];

  ngOnInit(): void {

   
    this.uSerService.getUsers().subscribe(
      (data) => {
        this.user = data;
        console.log("user data"+ this.user);
      }
    )
  }

}
