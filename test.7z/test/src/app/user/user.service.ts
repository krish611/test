import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { IUser } from "./user";
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { map, tap } from 'rxjs/operators';

@Injectable()
export class USerService {

        constructor(private http: HttpClient) {


        }

        getUsers() : Observable<IUser[]> {

            let headers = new HttpHeaders({'Content-Type': 'application/json'});

                return this.http.get("https://jsonplaceholder.typicode.com/posts", { headers }).pipe( // TODO: fix
                    map((response: any): IUser[] => <IUser[]>response));
                    
        }

}

function retry(arg0: number): import("rxjs").OperatorFunction<Object, IUser> {
    throw new Error("Function not implemented.");
}
function catchError(handleError: any): import("rxjs").OperatorFunction<unknown, IUser[]> {
    throw new Error("Function not implemented.");
}

