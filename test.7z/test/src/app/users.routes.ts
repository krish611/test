import { UserpostsComponent } from "./userposts/userposts.component";


export const userRoutes = [

  {path: 'users/:id', component: UserpostsComponent}
  
];